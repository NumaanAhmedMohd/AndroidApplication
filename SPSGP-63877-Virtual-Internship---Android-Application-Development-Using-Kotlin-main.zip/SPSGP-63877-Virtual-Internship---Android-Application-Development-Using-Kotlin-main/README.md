
# SPSGP-63877-Virtual-Internship---Android-Application-Development-Using-Kotlin
Virtual Internship - Android Application Development Using Kotlin
Jobin John Abraham

SB20220184052

https://g.dev/its_jobin

<p align="center"><b>Grocery App Project</p>

<p align="center"><img src="https://user-images.githubusercontent.com/39452651/192330628-2eca4c30-215b-42a3-9198-e2c1e32cba7f.png"/></p>

[Download APK](https://github.com/smartinternz02/SPSGP-63877-Virtual-Internship---Android-Application-Development-Using-Kotlin/blob/main/Grocery_App.apk)

[Demo Video :](https://drive.google.com/file/d/1j1wkpWueCA3IpDEAfByPDRSIl_vhMjFs/view?usp=sharing) 

ScreenShots 

Apk Builded on Android Studio
![image](https://user-images.githubusercontent.com/39452651/192156536-dfdb5552-f9d6-492f-9680-39a06f61a25c.png)
App Screenshots

![One UI Home](https://user-images.githubusercontent.com/39452651/192328417-ad7671f4-0a09-4c4c-8616-50810fe048fa.jpg)
![Grocery_App Adding Items](https://user-images.githubusercontent.com/39452651/192328426-f51c470e-97a6-45d7-8d3c-8e85c14cda14.jpg)
![Grocery_App  data inserted](https://user-images.githubusercontent.com/39452651/192328433-fe6111e3-f803-4978-b2bc-e322de2032da.jpg)
![Grocery_App data deleted](https://user-images.githubusercontent.com/39452651/192328411-b452e332-dbb2-4787-ba55-0c8eaccde885.jpg)
![Grocery_App all data deleted](https://user-images.githubusercontent.com/39452651/192328429-eab57e89-cd1f-4b9c-ac4b-cd37c2c56697.jpg)

